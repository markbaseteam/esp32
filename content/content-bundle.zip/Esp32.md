# Descrizione ESP32
Gli MCU (MicroControllerUnit) ESP32 sono sviluppati e prodotti dall'azienda [Espressif](https://www.espressif.com/).  Di conseguenza tutta la documentazione tecnica ufficiale è prodotta e caricata sul loro sito web.

Vi è un'ampia scelta di moduli e architetture con caratteristiche diverse a seconda dei casi d'uso.

Un importante distinguo va fatto sulle modalità e capacità di connettività di queste board, in quanto hanno un modulo integrato wi-fi, ma che supporta **solo** la banda 2.4GHz. Di conseguenza è importante tenerne conto nell'ottica di connessione a router, AP o dispositivi , che negli ultimi periodi hanno una facilità ad autoconfigurarsi sulla 5GHz , qualora sia disponibile.

I modelli con relative schede tecniche e documentazione possono essere cercati e trovati al seguente sito:
- [modelli e documentazione Esp32](https://products.espressif.com/#/product-selector?language=en)

Nel caso del progetto in esame è opportuno scegliere una scheda recente con supporto a più modalità di connessione e con una memoria interna  ( flash, rom, psram ) sufficientemente ampia per poter ospitare casistiche di configurazione di complessità crescente , delle quali non si può fare una stima a priori ( non si può sapere il risultato finale del file di configurazione compilato e quindi quanto occupa sulla board, di conseguenza una scelta della memoria interna "per stare larghi" sarabbe  da preferire ).

La scelta ha necessità di ricadere su board di architettura ovviamente non RISC-V ( sarebbe interessante programmare l'instruction set della cpu, ma va ben oltre lo scopo del progetto ), in particolare i modelli ESP32-S3 sembrano incarnare caratteristiche desiderabili , quali:
- numero di GPIO ( in volgare detti "pin") sufficientemente alto da poter ospitare più test su diversi protocolli per quanto riguarda il reparto sensori.
- memoria capiente rispetto ad altri modelli
- reparto connettività ampio e moderno : BLE ( BT Low Energy 5.0 ), Wi-Fi 802.11 b/g/n  2.4 GHz, e altre modalità di connessione riportate brevemente nello schema logico in figura.
- costo contenuto
- cpu dual-core 
- documentazione completa 

### Diagramma logico del modello ESP32 - S3
![[description.png]]

Di particolare interesse su questo schema sono le interfacce per le periferiche:
- I2C
- SPI
- I2S 
Queste sono le "modalità" ( protocolli ) di connessione dei sensori alla board ( insieme alle altre sul diagramma ), e in base al pinout ( la configurazione dei pin della board ) e al tipo di sensori potrebbe risultare impossibile il collegamento di due sensori su stessa interfaccia: ad esempio La I2C sfrutta gli unici 2 GPIO presenti sulla board che la abilitano (oltre alla presa a terra **GND**, e l'alimentazione che a seconda del sensore varia tra 3.3v e **VIN** a 5v ) , cioè **SCL** e **SDA** riportati in questo esempio nei GPIO 22 e 21 di un modello chiamato ESP-WROOM-32 ( è il classico che si trova da arduiner ). 

#### Pinout ESP-WROOM-32
![[Pasted image 20220728114933.png]]
nel caso in esempio la board contiene 25 GPIO, con il protocollo di comunicazione **I2C** ( Inter Integrated Circuit ), risulta evidente che si può connetere un solo sensore che sfrutti questa modalità , non avevdone altri a disposizione liberi.
Gli altri protocolli spaziano dall'analogico , al digitale,  al seriale nel caso **SPI** ( Serial Peripehral Interface) . 



Sulla scelta possono impattare diversi fattori, qualora l'acquisto non venga effettuato da vendors ufficiali Espressif ( ci sono i links di rimando dal loro sito ) , vanno verificati esattamente i nomi modello : 
- Le esp32-S3 si suddividono in :
	- ESP32 - S3 ( "di fabbrica "), è quella che ha più GPIO ( 45 ) 
	- ESP32 - S3 - WROOM 1/ 2 / 1U: 
		- questi modelli sono una caratterizzazione delle S3 e sono quelle più commercializzate ( si trovano su qualsiasi shop online e offline , vedi arduiner ), hanno un numero di pins inferiore , ma caratteristiche analoghe. 

Inoltre va tenunto in conto il modello di "SINGLE-CHIP USB-TO-UART BRIDGE":
questo viente comunemente indicato con la nomenclatura **CP201x** nel caso delle board citate, in quanto ve ne sono di vari modelli ( in particolare con il numero 2 e 9 al posto della x), e sono dei chip saldati sulla board che svolgono il ruolo dei precedenti convertitori UART .
In precedenza infatti per potersi collegare alla board, era necessario avere un convertitore esterno da usb a pin sulla board. Il numero modello di questo chip diventa importante in quanto i drivers per il chip , da installare in locale , permettono il corretto funzionamento e collegamento della board. I drivers e relativa documentazione tecnica si trovano al sito dell'azienda che li produce :  [silicon labs](https://www.silabs.com/)


### Considerazioni pratiche 
Vanno tenute in considerazione:
1. Tensione di alimentazione
	- è solitamente 5V ma va verificata sulla board scelta .
	- Questa tensione corrisponde a **VIN** sul pinout ( V -> tensione, In -> ingresso )
	- Se alimentata tramite micro usb, il cavo stesso e il dispostivo che alimenta ( pc, powerbank, trasformatore) , funge già da ripartitore di tensione, evitandoci il ruolo di doverlo prevedere e inserire noi.
	- In casi di utilizzo pratico si consideranno le batterie ti tipo "Lipo" , sono batterie a polimeri di Litio, analoghe a quelle presenti sugli smartphone, sono le classiche batterie utilizzate per alimentare progetti di elettronica che hanno il requisito di autonomia.
2. Numero di GPIO e loro presentazione hardware:
	- in commercio si trovano sia schede con pin saldati, sia non. Quest'ultimo caso è solitamente preferito in caso di testing, in quanto l'usura della scheda nell'inserire ed estrarre i jumpers da collegare ai pin può causarne la loro rottura o malfunzionamento.
	- Il numero di GPIO incide sulla quantità di sensori associabili , nel progetto è poco rilvante se ne usiamo uno , o qualcuno in più . 
3. Cavo dati:
	- va distinto il cavo dati micro-usb di alimentazione da quello dati. Possono coincidere, ma solitamente non tutti i cavi di alimentazione portano dati , e diventa invece fondamentale nella fase di connessione computer - board per la sua configurazione ( non riconosce il dispositivo associato su una porta seriale e di conseguenza non gli può passare alcun dato).


